----------------------------
Virtual MySQL-python package
----------------------------

This package is a 'virtual package', which requires MySQL-python to install.
In effect, this means 'pip install mysql' will actually install MySQL-python.

Please see https://pypi.python.org/pypi/MySQL-python for the actual package.


